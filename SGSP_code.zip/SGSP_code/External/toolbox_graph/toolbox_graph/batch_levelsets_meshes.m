name_list = {'bunny' 'david50kf' 'hand' 'lion-head' 'david_head' 'aphro' 'gargoyle' 'screwdriver' 'elephant-50kv'};


for itname = 1:length(name_list)
    name = name_list{itname};
    test_levelset_mesh;
end