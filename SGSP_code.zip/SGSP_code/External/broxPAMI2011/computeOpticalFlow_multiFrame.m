
function [flow] = computeOpticalFlow_multiFrame(frames,opticalflow_path )    
   
    if( ~exist( opticalflow_path, 'dir' ) )
        mkdir( opticalflow_path );
        addpath(genpath(opticalflow_path));
    end
    
    
    fprintf('computeOpticalFlow: Processing \n');
%   filename = fullfile( opticalflow_path, 'LDOF_opticalFlow_multi_double' );
    filename1 = fullfile( opticalflow_path, 'LDOF_opticalFlow_pairwise' );
    if( exist( filename1, 'file' ) )
        % Shot already processed, skip
        fprintf('computeOpticalFlow: Data processed, skipping...\n' );
        return;
    else               
        [flow,totalTimeTaken]=computeBroxLDOF_multiFrame(frames);         
        save( filename1, 'flow' );
        %fprintf( 'compute MultiFrame OpticalFlow: finished processing\n');
        %[flow] = computeOpticalFlow(frames,opticalflow_path);
        %fprintf( 'compute pairWise OpticalFlow: finished processing\n');
    end
    
   
    
end
